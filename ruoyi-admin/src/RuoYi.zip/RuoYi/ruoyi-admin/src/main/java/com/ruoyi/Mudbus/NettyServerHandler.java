package com.ruoyi.Mudbus;

import com.ruoyi.iot.domain.TDevice;
import com.ruoyi.iot.domain.THistory;
import com.ruoyi.iot.service.ITDeviceService;
import com.ruoyi.iot.service.ITHistoryService;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class NettyServerHandler extends SimpleChannelInboundHandler {

    public static NettyServerHandler nettyServerHandler;
    //注入物联网终端数据操作服务
    protected ITDeviceService itDeviceService;

    //注入历史数据操作服务
    protected ITHistoryService itHistoryService;

    /**
     * 构建函数
     */
    public NettyServerHandler(){

    }

    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, Object o) throws Exception {

    }

    /**
     * 处理接收数据
     * @param ctx
     * @param o
     */
    protected void messageReceived(ChannelHandlerContext ctx,Object o){
        //提取有效数据
        byte[] bytes=(byte[])o;
        //显示接收数据
        String strData=NettyServer.byteToHexSpring(bytes);
        System.out.println("服务器收到Message:"+strData);
        //解析并保存数据
        //int rest =SaveData(getZh(bytes),getwendu(bytes),getShuiwei(bytes));
        int rest =SaveData(getzh(bytes),getwendu(bytes),getShuiwei(bytes));
       System.out.println("保存数据:"+rest+"条！");
    }
    //        初始化服务器处理
    @PostConstruct
    public void init(){
        nettyServerHandler=this;
        nettyServerHandler.itDeviceService=itDeviceService;
        nettyServerHandler.itHistoryService=itHistoryService;
    }

    /**
     * 通道数据读取完成时间
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        //super.channelReadComplete(ctx);
        System.out.println("data ok!");
    }

    /**
     * 异常错误处理
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        //super.exceptionCaught(ctx, cause);
        System.out.println("error!"+cause.getMessage());
        ctx.close();
    }

    /**
     * 客户端连接触发
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        //super.channelActive(ctx);
        System.out.println("客户端激活....");
        ctx.writeAndFlush("hello client!");
    }

    /**
     * 解析温度
     * @param bdata
     * @return
     */
    public BigDecimal getwendu(byte[] bdata){
        //取字节数第10组数据，并消除负值
        int iHigh=0xff&bdata[9];
        //取字节数第11组数据，并消除负值
        int iLow =0xff&bdata[10];
        float fVal=(iHigh*255+iLow)/100.0f;
        BigDecimal result=new BigDecimal(Float.toString(fVal));
        System.out.println("温度"+result);
        return result;
    }

    /**
     * 解析水位
     * @param bdata
     * @return
     */
    public BigDecimal getShuiwei(byte[] bdata){
        //取字节数第12组数据，并消除负值
        int iHigh=0xff&bdata[11];
        //取字节数第13组数据，并消除负值
        int iLow =0xff&bdata[112];
        float fVal=(iHigh*255+iLow)/100.0f;
        System.out.println("f水位"+bdata[11]+"-"+bdata[12]);
        BigDecimal result=new BigDecimal(Float.toString(fVal));
        System.out.println("水位"+result);
        return result;
    }
    /**
     * 解析站号
     * @param bdata
     * @return
     */
public  long getzh(byte[] bdata){
    long istation=bdata[6];
    return istation;

}
    public static int SaveData(long zh,BigDecimal wd,BigDecimal sw){
        //查询该站号设备列表
        TDevice tDevice=new TDevice();
        tDevice.setStation(zh);
        List<TDevice> devices=nettyServerHandler.itDeviceService.selectTDeviceList(tDevice);
        int Reult=0;

        if (!devices.isEmpty()){
            for (TDevice td:devices){
                //更新物联网终端设备实时数据
                //td.setTemperature(wd);
                td.setWaterlevel(sw);
                td.setUptime(new Date());
                nettyServerHandler.itDeviceService.updateTDevice(td);
                Reult++;
                //插入历史数据
                THistory th=new THistory();
                th.setDeviceid(td.getId());
               // th.setTemperature(wd);
                th.setWaterlevel(sw);
                th.setUptime(new Date());
                nettyServerHandler.itHistoryService.insertTHistory(th);
                Reult++;
            }
        }

        return Reult;
    }

}
